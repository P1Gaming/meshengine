public enum BlockType
{
    Air,
    Grass,
    debug1,
    debug2,
    debug3,
    debug4,
    debug5,
    debug6,
    debug7,
    debug8,
}