namespace MeshEngine.SaveSystem
{

    internal interface ISaveData
    {
        public void SaveChunkData(ChunkData chunkData);

    }
}